# Big Buddha and funeral home rights: how China is tackling its massive debt burden

- 来源：the Guardian　|　发布：2023-02-27　|　作者：Amy Hawkins　|　正文字符：4133
- 原文：https://www.theguardian.com/world/2023/feb/27/big-buddha-and-funeral-home-rights-how-china-is-tackling-its-massive-provincial-government-debt-burden

Zero-Covid spending and lower taxes has led to £4.2tn in local government debt, posing a ‘big headache’ for the economy

In China’s Sichuan province, Leshan city has plans to sell the operating rights to the Big Buddha, a 71-metre tall Tang dynasty stone statue, in one of a series of creative methods cash-strapped local governments are using raise money.

Having spent more than £42bn last year on Covid-prevention measures, and hit by falling tax revenues, by December 2022 local governments had accumulated 35tn yuan (£4.2tn) in debt, up from 30.5tn yuan the previous year. That means that China’s provincial debt burden is roughly 20% bigger than Germany’s total GDP. In 2022 Hegang, a city in the northern province of Heilongjiang, became the first city in China to undergo a fiscal restructuring.

Economic statistics for 2022 will be published on Tuesday. Preliminary estimates suggest growth slumped to 3%, the worst showing since 1976. The national growth target for GDP will be announced at the National People’s Congress, which starts on 5 March. The target is expected to be at least 5% – an ambition that could drive local officials to prioritise spending rather than saving.

The crackdown on the property industry also hit local government coffers. Revenue relating to land sales typically accounts for more than 30% of local government income and between 2019 and 2021 the share was about 40%. But last year land sale revenues declined by nearly one-third compared with 2021.

Local government debt is a “big headache” for the national economy, said Wenye Sun, an analyst at research firm Trivium China.

“There are real risks that more low-level governments will default on their debt obligations,” said Sun. “In the worst-case scenario this will spark a financial crisis.”

Hidden debts accumulated through local government financing vehicles, mechanisms that are used to fund infrastructure projects, could more than double the total debt burden.

Houze Song, a fellow covering the Chinese economy at MacroPolo, a thinktank, estimates that debt held in local government financing vehicles is already more than 70% of GDP.

Faced with dwindling coffers, some municipalities are turning to new ways to generate funds. As is the case in Leshan, one approach is to flog local assets. In August, it announced plans to sell the 30-year rights to the giant Buddha statue, starting at 1.7bn yuan. Rongjiang county in Guizhou, a poor province in south-west China, auctioned off the operating rights to its local funeral home for 126.8 million yuan.

In September employees of the public transportation network in the northern city of Lanzhou, who had not been paid for several months, were asked to take out a loan from a local bank to cover their wages from June to September. The state-owned company owed about 90 million yuan in unpaid wages, but promised its workers that it would repay the bank loans on their behalf. But local governments already owe billions: last year 2.6tn yuan of refinancing bonds were issued, and more than 1tn yuan was paid in interest alone.

The re-opening of China’s economy should help to balance the books. Tax revenues increased by nearly 70% in December, compared with December 2021. Under the zero-Covid policy Beijing introduced tax cuts on a record scale to help businesses survive – which hit municipal incomes.

Between 2020 and 2021, 15 prefecture-level authorities more than doubled their income from fines. Some local traffic authorities have resorted to asking drivers to pay a monthly “fine package” of 2,000 yuan to cover the cost of any potential future violations.

Yet some experts are skeptical over how effective the steps taken by local governments will be.

In a blogpost Luo Zhiheng, an economist, warned that some of the tactics employed by local authorities could amount to “fishing in a dry lake” to try to squeeze cash out of ordinary people.

MacroPolo’s Song said that local governments have been “prioritising debt rollover, instead of debt repayment.”

“As a result, debt continues to grow faster than GDP,” he said. “Selling assets or fines will only offer marginal help for solving debt.”
