# China Sends Youngest-Ever Crew to Space as It Seeks to Put Astronauts on Moon

- 来源：voanews.com　|　发布：2023-10-26　|　正文字符：2794
- 原文：https://www.voanews.com/a/china-sends-youngest-ever-crew-to-space-as-it-seeks-to-put-astronauts-on-moo/7328094.html

China launched its youngest-ever crew for its orbiting space station on Thursday as it seeks to put astronauts on the moon before 2030.

The Shenzhou 17 spacecraft lifted off from the Jiuquan Satellite Launch Center on the edge of the Gobi Desert in northwestern China atop a Long March 2-F rocket at 11:14 a.m. (0314 GMT)

According to the China Manned Space Agency, the average age of the three-member crew is the youngest since the launch of the space station construction mission, state broadcaster CCTV earlier reported. Their average age is 38, state media China Daily said.

China's Shenzhou-16 Mission Takes Off Bound for Space Station

Beijing is pursuing plans to place astronauts on the moon before the end of the decade amid a rivalry with the U.S. for reaching new milestones in outer space. This reflects the competition for influence between the world's two largest economies in the technology, military and diplomatic fields.

The trio — Tang Hongbo, Tang Shengjie and Jiang Xinlin — will replace a crew that has been on the station for six months. Tang is a veteran who led a 2021 space mission for three months.

The new crew will conduct experiments in space medicine, space technology and other areas during their mission and will help install and maintain the equipment inside and outside the station, the agency said.

On Wednesday, the agency also announced plans to send a new telescope to probe deep into the universe. CCTV said the telescope would enable surveys and mapping of the sky, but no timeframe was given for the installation.

China has researched the movement of stars and planets for thousands of years while in modern times, it has pushed to become a leader in space exploration and science.

It built its own space station after it was excluded from the International Space Station, largely due to U.S. concerns over the control of the program by the People’s Liberation Army, the military branch of the ruling Communist Party.

China’s first manned space mission in 2003 made it the third country after the former Soviet Union and the U.S. to put a person into space using its own resources.

American spending, supply chains and capabilities are believed to give it a significant edge over China, at least for now. China has broken out in some areas, however, bringing samples back from the lunar surface for the first time in decades and landing a rover on the less explored far side of the moon.

The U.S., meanwhile, aims to put astronauts back on the lunar surface by the end of 2025 as part of a renewed commitment to crewed missions, aided by private sector players such as SpaceX and Blue Origin.

In addition to their lunar programs, the two countries have also separately landed rovers on Mars, and China plans to follow the U.S. in landing a spacecraft on an asteroid.
