# Workers in China worry over being replaced as they adapt to the growing impact of AI on jobs

- 来源：Tri City Record　|　发布：2026-08-23　|　作者：CHAN HO-HIM and FU TING　|　正文字符：8104
- 原文：https://www.tricityrecordnm.com/articles/associated-press-new-mexico/workers-in-china-worry-over-being-replaced-as-they-adapt-to-the-growing-impact-of-ai-on-jobs/

CHAN HO-HIM and FU TING

Associated Press

Sunday, Aug 23, 2026 9:42 PM MT

Updated Tuesday, Sep 1, 2026 8:13 AM MT

Already a subscriber?

One quick step

## Check your email

We sent a confirmation link to . Open that email and click the link to return to this article. Your free reads begin after confirmation.

The link works for 24 hours. If it opens in another browser, return to this tab after confirming and it will unlock automatically. A new browser still needs a secure email sign-in link.

Monthly reader access

## You’ve used your 3 free articles this month.

Sign in with an active subscription or subscribe for unlimited access.

HONG KONG (AP) — Computer programmer Fei Zhaojun’s boss asked him if artificial intelligence could soon replace humans in coding jobs. Two weeks later, he was laid off from his job in Beijing, together with about 160 of his colleagues.

It’s an increasingly common scenario as artificial intelligence, supported by government policies, reshapes China’s massive job market. Some economists believe that might eventually undermine the overall strength of the world’s second largest economy.

Rapid adoption of AI in many fields, from computer programmers to script writing and physical tasks, is pushing people out of their jobs or leaving them afraid that it might. China is at the vanguard of AI adoption as government policies encourage people and businesses to use AI applications and robotics in all aspects of life, so people like Fei are figuring out how to adapt.

“There appears to be far less anti-AI sentiment in China (than elsewhere). Most people seem either positive, neutral, or mildly interested in AI,” said Shujing He, a Beijing-based senior analyst at advisory and research firm Plenum.

“Individuals who worry about being replaced, as well as those who have already left traditional workplaces, are often eager to experiment with AI-enabled businesses and independent ventures,” she said. “The level of interest is striking.”

Until recently, Fei had doubted AI could do programming work perfectly, even though his bosses thought it was close enough.

“Mid-level coders’ job are essentially replaceable in most of the cases,” said Fei, 40. “Even if it is a disaster that leads to replacing all humans, at this stage, you just have to use it as everyone else is using it.”

Now he’s making vlog-style short videos during a career break while figuring out what he wants to do next. He’s not making a living off of his videos, which are about ordinary people’s lives, but hopes that they might help others.

If you can’t beat them, join them

Du Qinchun, a part-time translator, has been helping to train an AI model to do translations. That’s brought him more work, at least temporarily.

“But it’s true that the pay in the industry has been cut by more than half compared to what it was years ago,” said Du, who is based in southwestern China’s Chengdu city.

The trend is so evident that popular college programs in foreign languages have increasingly fallen out of favor as AI-powered translation tools have become more widespread.

The share of Chinese industrial enterprises saying they use AI models and “agents” jumped to 47.5% last year from 9.6% in 2024, according to the market intelligence firm IDC.

“China’s vibrant open-source model ecosystem fosters greater AI application innovation in industrial settings, gradually closing the gap between foundational model capabilities and real-world enterprise value creation,” said Yanze Du, an IDC senior research manager in Beijing.

Humanoid robots can now, for example, sort parcels in postal centers, although still on a small-scale basis, and are pushing the boundaries in performing more human tasks such as directing traffic and making coffee. Food delivery robots are also gaining ground across the country, potentially threatening the livelihoods of millions of Chinese food delivery workers.

Generative AI increasingly is used for creation, production and distribution in China’s short drama industry. The number of live-action short and vertical video series designed for mobile phones fell about 75% in the first quarter of this year from a year earlier, according to Chinese media reports.

“Tasks that once required specialized training can now be performed by almost anyone with access to AI tools. This is particularly evident in software development and multimedia creation,” said Plenum’s He. “As a result, workers whose roles are narrowly concentrated in these areas may face greater displacement risk.”

A report from International Labor Organization, meanwhile, found that women face higher risks of losing employment due to use of AI than men, as they tend to work in areas more suitable for automation, such as assembling electronics, and remain underrepresented in science and technology.

AI has mixed effects on the slowing economy

Under China’s “AI Plus” initiative and its five-year plan through 2030, the government is pushing to infuse AI across many industries, aiming to gain an edge in China’s technology rivalry with the U.S.

“What is specific to China is that the government is really into diffusing AI across the economy, so AI may get into different domains more quickly comparing to other countries,” said Zilan Qian, a research associate at Oxford China Policy Lab.

China’s economic growth has already been slowing. Consumer spending has lagged partly due to people becoming reluctant to spend because they’re worried about losing their jobs. It’s added to problems stemming from a prolonged downturn in the housing market that has undermined household wealth.

China’s tech industries may be innovative with high productivity, but they may not generate many new jobs, said Eswar Prasad, a professor of economics and trade policy at Cornell University.

“AI is likely to lift productivity across the board but could have a severe disruptive effect on employment, worsening the employment growth problem and resulting in a detrimental effect on social stability,” he said.

Similar to their U.S. rivals, Chinese tech giants have cut or restructured tens of thousands of jobs, partly due to AI. The outlook for the broader jobs market remains uncertain: China’s overall urban unemployment rate hovers around 5%, but unemployment for people aged 16 to 24, excluding students, is roughly triple that.

That said, in the longer run, some experts say unemployment rates could fall, since China’s population of 1.4 billion is rapidly aging and shrinking.

By 2050, China is projected to have fewer than two working-age adults to support each retiree, compared with more than 2.5 in the U.S., said Xuenan Cao, a professor at San Francisco Bay University whose focus includes technology and society.

“Automation could partially offset a shrinking workforce rather than being purely a threat to it,” Cao said.

Some embrace AI to find new ways to make a living

Wang Zhicheng, 32, often used AI for brainstorming and fact-checking in his previous job as a scriptwriter for a company that produces 3D animated educational videos and interactive exercises for children.

After its parent company laid off roughly half of its 13 script writers, he chose to resign and work independently, making illustrated children’s books.

While AI sometimes saved time the scripts it generated, they often felt strange, Wang said. Episodes tended to be repetitive and formulaic and the level of detail devoted to knowledge varied widely.

“You can treat AI as a tool just like (Microsoft) Word,” said Wang, who has started his own studio making picture books and other creative works. “Humans are still the decision makers on which one to pick or pursue among all that AI generates.”

High school chemistry teacher Yang Zheng said he doesn’t consider AI as a threat to his job even though students use AI for help with their homework.

“Teachers cannot be there all the time,” he said. “It is a good thing for students as it generates in real-time so that students can ask follow-up questions,” said Yang, 29. “It often gets things wrong, but it improves over time.”

____

Fu Ting reported from Washington. AP video producer Wu Jia in Beijing contributed to this story.
