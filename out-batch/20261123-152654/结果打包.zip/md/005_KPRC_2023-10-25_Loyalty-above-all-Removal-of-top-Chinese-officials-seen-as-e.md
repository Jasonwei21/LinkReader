# Loyalty above all: Removal of top Chinese officials seen as enforcing Xi's demand for obedience

- 来源：KPRC　|　发布：2023-10-25　|　作者：Christopher Bodeen　|　正文字符：4853
- 原文：https://www.click2houston.com/news/world/2023/10/25/loyalty-above-all-removal-of-top-chinese-officials-seen-as-enforcing-xis-demand-for-obedience/

Christopher Bodeen

Associated Press

FILE - Newly elected Chinese Defense Minister Gen. Li Shangfu takes his oath during a session of China's National People's Congress (NPC) at the Great Hall of the People in Beijing on March 12, 2023. China has replaced Defense Minister Gen. Li, who has been out of public view for almost two months with little explanation, state media reported Tuesday, Oct. 24. (AP Photo/Andy Wong, File)

TAIPEI – The removal of China’s foreign and defense ministers appears to enforce leader Xi Jinping’s demand for total obedience and the elimination of any potential rivals within the ruling Communist Party, analysts say.

State media this week confirmed that former defense minister Gen. Li Shangfu and former foreign minister Qin Gang were “no longer serving in office,” but offered no details.

Recommended Videos

The opacity of China’s one-party authoritarian system creates huge speculation about why the officials left office and whether they will face legal censure. Both Li and Qin were appointed under Xi’s watch, indicating they must have undergone close scrutiny, but later faced doubt over their personal behavior or political alliances.

“It’s possible to see the reshuffle either as a manifestation of (Xi's) weakness or a sign of his strength. I lean toward the insecurity side of the explanation,” said June Teufel Dreyer, an expert on Chinese politics at the University of Miami in the U.S.

Xi is breaking with precedent by taking down his own powerful appointees, further turning the entire Communist Party “into the Xi faction,” said Steve Tsang, director of the China Institute at the University of London's School of Oriental and African Studies.

Almost no information has been offered about the fate of Li and Qin, who was removed from office in July amid speculation of his having violated an unwritten code of ethics that is often used as cover for political infighting.

Li, who became defense minister during a Cabinet reshuffle in March and was dispatched to Moscow on a visit to shore up China's backing of Russia, hasn’t been seen since giving a speech on Aug. 29.

There is no indication that the disappearances of Qin and Li signal a change in China’s foreign or defense policies, which seek to form alliances in opposition to the liberal democratic world order led by the U.S. and its allies.

Li’s ouster was likely based on multiple factors, including an anticorruption investigation linked to the equipment development department dating back to 2017, said Meia Nouwens, a China expert with the International Institute for Strategic Studies.

“This doesn’t look good. They are your close allies, you’ve only just appointed them and now clearly something has happened that isn’t positive for them to take such drastic actions and remove them from their positions in what seems like quite a hasty way,” Nouwens said.

At the same time, some could see the move as a sign of Xi’s strength, she said.

It shows “weakness in his inner circle, but clearly strength in the sense that he ... can take these decisions quite decisively if he so chooses,” she said.

Xi has a reputation for valuing loyalty above all and has relentlessly attacked corruption in public and private, sometimes in what has been seen as a way of eliminating political rivals and shoring up his political position amid a deteriorating economy and rising tensions with U.S. over trade, technology and Taiwan.

Li is under U.S. sanctions related to his oversight of weapons purchases from Russia that bar him from entering the country. China has since cut off contact with the U.S. military, mainly in protest over U.S. arms sales to Taiwan, and strongly implied that Washington must lift the measures against Li that Beijing refuses to publicly recognize.

State broadcaster CCTV this week also announced the appointment of new finance minister and science and technology ministers.

China’s political and legal systems remain opaque, fueling lively discussion of possible corruption, personal foibles or fallings-out with other powerful figures leading to the downfall of top officials.

China's ruling party is also struggling to revive an economy that has been severely impacted by draconian “zero COVID” measures, an aging population, high unemployment among college graduates and a movement of many of its wealthiest and best educated to more liberal societies abroad.

With his ideology, known as “Xi Jinping Thought,” enshrined in the party constitution and with the abolishment of presidential term limits, Xi has structured the system so that he may stay in power for the rest of his life.

The 70-year-old also heads the party and state committees overseeing the People’s Liberation Army, the world’s largest standing military with more than 2 million personnel on active duty.

___

Associated Press writer David Rising contributed to this report from Bangkok.
