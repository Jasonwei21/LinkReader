# China meets its official growth target. Not everyone is convinced | Mint

- 来源：mint　|　发布：2025-01-19　|　作者：list.metadata.agency　|　正文字符：4259
- 原文：https://www.livemint.com/economy/china-meets-its-official-growth-target-not-everyone-is-convinced-11737261493723.html?showGiftPopup=true

- For one thing, 2024 saw the second-weakest rise in nominal GDP since the 1970s
This is a Mint Premium article gifted to you. Subscribe to enjoy similar stories.

The company at the heart of “Severance”, a celebrated TV show that just began its second season, features a department of “Macrodata Refinement”. Its workers must spot disconcerting numbers and lock them away in a digital bin. Does China’s National Bureau of Statistics (NBS) have a similar department? If so, it excelled itself this week.

On January 17th the NBS reported that China’s economy grew by exactly 5% in 2024. The lovely round number was bigger than expected, but precisely in line with the official growth target. China’s economy managed this feat despite an ongoing property slump, dismal consumer morale and demographic decline: the population shrank by almost 1.4m last year. The NBS attributed the recovery to stimulus policies rolled out since September. “Major development targets” were achieved successfully, it said. The government is likely to approve a similar growth target for 2025 when its rubber-stamp legislature gathers in March.

Other, more granular data suggest the economy did gain some momentum towards the end of last year. Exporters rushed to fulfil orders in the expectation that America will raise tariffs on China soon after Donald Trump returns as president. Retail sales also benefited from an old-for-new upgrading scheme that encourages households to replace their old cars and electrical goods with newer, greener versions. Sales of household appliances leapt by 39% year on year in December, the second-highest figure in data going back to 2007.

People, then, seem eager to buy new stuff for their homes. But are they also more willing to buy new homes for their stuff? The answer is a tentative yes: the property market appears to be stabilising. Developers sold 4% more residential floor space in December than they did a year ago, the second monthly increase in a row. Prices stabilised, too. The monetary stimulus unveiled since September 24th may have helped, especially the central bank’s efforts to cut mortgage rates.

Nurturing this recovery will be difficult. Although the central bank seems keen to cut interest rates further, that would weaken the yuan, which is already under pressure as American government-bond yields rise and Chinese yields tumble. If Mr Trump starts a new trade war, exports will suffer, shrouding one of the economy’s bright spots. In light of such dangers, the government has said it will increase its official budget deficit this year to boost demand. But its traditional channels of fiscal stimulus, such as infrastructure investment, face diminishing returns. And its less conventional schemes, such as the upgrading programmes, have limitations. There are only so many times a household can trade in a fridge.

Moreover, despite the efforts of China’s macrodata refiners, some troubling statistics remain. The economy’s apparently brisk growth was accompanied by sustained deflation. Nominal growth, which makes no adjustment for price changes, was only 4.2% last year, once revised data from China’s recent economic census is factored in. That was the second-weakest figure since the 1970s. It implies prices across the economy fell by more than 0.7% last year.

The mismatch between strong GDP and weak inflation strikes many economists as odd. Some believe China’s official growth figures have become severed from reality. “My own speculation is that in the past two to three years, the real [growth] number on average might be around 2% even though the official number is close to 5%,” said Gao Shanwen of SDIC Securities last month. His comments upset China’s leaders, who do not want scepticism about their statistics to undermine confidence in the economy’s recovery. Mr Gao’s WeChat social-media account was blocked and, according to the Wall Street Journal, he has been banned from public speaking for the time being.

This will do nothing to lift spirits, of course: good economic news will not be credible if bad news is unmentionable. To sustain its economic recovery, China needs stimulus not censorship. The best approach to locking away doubts about China’s macrodata is to tangibly improve China’s macroeconomy.
