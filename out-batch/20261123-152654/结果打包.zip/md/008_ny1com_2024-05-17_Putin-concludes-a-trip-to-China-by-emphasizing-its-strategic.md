# Putin concludes a trip to China by emphasizing its strategic and personal ties to Russia

- 来源：ny1.com　|　发布：2024-05-17　|　作者：Associated Press　|　正文字符：5542
- 原文：https://ny1.com/nyc/all-boroughs/ap-top-news/2024/05/17/putin-concludes-a-trip-to-china-by-emphasizing-its-strategic-and-personal-ties-to-russia

BEIJING (AP) — Russian President Vladimir Putin concluded a two-day visit to China on Friday, emphasizing the countries’ burgeoning strategic ties as well as his own personal relationship with Chinese leader Xi Jinping as they sought to present an alternative to U.S. global influence.

Putin praised the growth in bilateral trade while touring a China-Russia Expo in the northeastern city of Harbin. He met students at the Harbin Institute of Technology, known for its defense research and its work with the People's Liberation Army.

Harbin, capital of China’s Heilongjiang province, was once home to many Russian expatriates and retains some of that history in its architecture, such as the central St. Sophia Cathedral, a former Russian Orthodox church.

Underscoring the personal nature of the relationship, Putin said the Harbin institute and his alma mater, St. Petersburg State University, will open a joint school for 1,500 students. “I’m sure that it will become a flagship of the Russian-Chinese cooperation in science and education,” he said

Speaking to reporters, Putin praised his talks with Xi as “substantive,” saying that he spent “almost a whole day, from morning till evening” with the Chinese leader and other officials in Beijing the previous day. As he departed Beijing, the two leaders embraced.

The partnership between China and Russia “is not directed against anyone,” Putin said in a veiled reference to the West. “It is aimed at one thing: creating better conditions for the development of our countries and improving the well-being of the people of China and the Russian Federation.”

“And it is important that those who are trying to maintain their monopoly on decision-making in the world on all issues ... do everything in their power to ensure that this process goes naturally,” he said.

Joseph Torigian, a research fellow at Stanford University’s Hoover Institute, said the message being sent by China and Russia was clear: “At this moment, they’re reminding the West that they can be defiant when they want to.”

In Washington, White House national security spokesman John Kirby played down the importance of the meeting, saying that although the two countries are acting in ways that are contrary to U.S. interests, they don’t have a long history of trusting each other.

Kirby noted that a U.S. intelligence assessment released last month indicates that China has surged sales to Russia of machine tools, microelectronics and other technology Moscow uses to produce missiles, tanks, aircraft and other weaponry. “But they’re also two leaders that don’t have a long history of working together, and officials in both governments that aren’t necessarily all that trustful of the other,” Kirby said.

Taiwan’s Foreign Minister Joseph Wu addressed Putin's visit in an interview with The Associated Press, saying Western powers should continue to support Ukraine as part of sending a message that democracies will defend one another.

“If Ukraine is defeated at the end, I think China is going to get inspired, and they might take even more ambitious steps in expanding their power in the Indo-Pacific, and it will be disastrous for the international community,” Wu said.

Putin this month began his fifth term in power and Xi began his third last year. The Russian leader's trip "is an example of the two big authoritarian countries supporting each other, working together with each other, supporting each other’s expansionism,” Wu added.

Russia has become isolated globally following the 2022 invasion of Ukraine. China has a tense relationship with the U.S., which has labeled it a competitor, and faces pressure for continuing to supply key components to Russia needed for weapons production.

Putin began the day by laying flowers at a Harbin monument to fallen Soviet soldiers who had fought for China against the Japanese during the second Sino-Japanese war, when Japan occupied parts of China.

“Relying on traditions of friendship and cooperation, we can look into the future with confidence,” he said. “The Russian-Chinese partnership helps our countries’ economic growth, ensures energy security, helps develop production and create new jobs.”

A joint statement on Thursday described their world view and expounded on criticism of U.S. military alliances in Asia and the Pacific. The meeting was yet another affirmation of the friendly “no-limits” relationship China and Russia signed in 2022, just before Moscow invaded Ukraine.

Talks of ending the fighting featured frequently in Thursday's remarks, although Russia has just opened a new front by launching attacks in Ukraine's northeastern border area. The war is at a critical point for Ukraine, which had faced delays in getting weapons from the U.S.

Since the invasion and subsequent Western sanctions on Moscow, Russia has increasingly depended on China for technology and some consumer imports while exporting cheap energy. Trade between the two countries increased to $240 billion last year.

European leaders have pressed China to influence Russia to end its invasion, to little avail. Experts say the Moscow-Beijing relationship offers strategic benefits, particularly when both have tensions with Europe and the U.S.

“Even if China compromises on a range of issues, including cutting back support on Russia, it’s unlikely that the U.S. or the West will drastically change their attitude to China as a competitor,” said Hoo Tiang Boon, who researches Chinese foreign policy at Singapore’s Nanyang Technological University. “They see very little incentive for compromise.”
