# Wall St falls on concerns over Fed interest rate path

- 来源：The Business Standard　|　发布：2022-11-04　|　作者：TBS Report　|　正文字符：4308
- 原文：https://www.tbsnews.net/world/global-economy/wall-st-falls-concerns-over-fed-interest-rate-path-525382

## Global Economy

US stocks were lower for a fourth straight session on Thursday as economic data did little to change investors' perceptions that the Federal Reserve would continue raising interest rates for longer than previously thought.

Equities had initially moved higher upon the release of the Fed's policy statement on Wednesday, which seemed to confirm hopes the Fed would begin to decelerate the size and speed of its path of interest rate hikes.

But comments from Fed Chair Jerome Powell following the statement that it was "very premature" to be thinking about pausing its rate hikes sent stocks lower as bond yields and the US dollar rose, a pattern that extended into Thursday.

#### Keep updated, follow The Business Standard's Google news channel

Economic data on Thursday showed a labor market that continues to stay strong, although a separate report showed growth in the services sector slowed in October.

"One key takeaway from yesterday was what matters is the ultimate level of rates and how long we stay there, those are to be determined, we are going to figure those out along the way," said Brad Conger, deputy chief investment officer at Hirtle Callaghan & Co in West Conshohocken, Pennsylvania.

"The bad news for stocks is obviously we are going to have to contend with more rate hikes than we thought."

The Dow Jones Industrial Average fell 24.21 points, or 0.08%, to 32,123.55, the S&P 500 lost 20.53 points, or 0.55%, to 3,739.16, and the Nasdaq Composite dropped 119.76 points, or 1.14%, to 10,405.04.

While traders are roughly evenly split between the odds of a 50 basis-point and 75 basis-point rate hike in December, the peak Fed funds rate is seen climbing to at least 5%, compared with a prior view of 4.50%-4.75% rise.

Investors will closely eye the nonfarm payrolls report due on Friday for signs the Fed's rate hikes are beginning to have a notable impact on slowing the economy.

The climb in yields weighed on megacap growth companies such as Apple Inc AAPL.O, down 3.59% and Alphabet Inc GOOGL.O which was down 3.20%. This in turn pulled down the technology and communication services sectors as the worst-performing in the session.

The Dow was able to hold near the unchanged mark thanks to gains in industrials including Boeing Co, up 6.68%, and heavy equipment maker Caterpillar Inc, which gained 2.85%.

Qualcomm Inc and Roku Inc lost 6.48% and 1.96%, respectively, after their holiday quarter forecasts fell below expectations.

With roughly 80% of S&P 500 having reported earnings, the expected growth rate is 4.7%, according to Refinitiv data, up slightly from the 4.5% at the start of October.

Declining issues outnumbered advancing ones on the NYSE by a 1.44-to-1 ratio; on Nasdaq, a 1.36-to-1 ratio favored decliners.

The S&P 500 posted 6 new 52-week highs and 44 new lows; the Nasdaq Composite recorded 57 new highs and 261 new lows.

### Comments

While most comments will be posted if they are on-topic and not abusive, moderation decisions are subjective. Published comments are readers’ own views and The Business Standard does not endorse any of the readers’ comments.

## Top Stories

- Defaulted loans rise to Tk6.27 lakh crore, nearly 34% of total loans
- No legal bar to holding public university admission tests before HSC re-exam results: Appellate Division
- Rooppur nuclear power plant begins second trial electricity supply to national grid
## MOST VIEWED

- Miley Cyrus marries Maxx Morando after 5 years of dating
- Give us Vietnam-like facilities; we will pay Vietnam-like wages: BGMEA president
- Govt opens public building rooftops for private solar investment
- Bangladesh must address key challenges to attract foreign investment: German ambassador
- Govt targets 35% GDP share from SMEs by 2031, says PM
- Alice Huang and her husband’s close associate Li Ming routed Nvidia chips to China: Report
### Jirati: The lives and livelihoods of Kishoreganj’s six-month farmers

### CFMoto 250SR: More than just a pretty face

### Beyond the negotiation halls: Six lessons from COP31 and a vision for Bangladesh

### AI is transforming legal practice. What does the future hold for lawyers?

## More Videos from TBS

### What are the police saying about the arrest of top criminal Sweden Aslam?

### How top terrorist Sweden Aslam was arrested?

### Is Libya emerging as a new front in the Russia-Ukraine war?

### Police killing in Narayanganj: What authorities say?
