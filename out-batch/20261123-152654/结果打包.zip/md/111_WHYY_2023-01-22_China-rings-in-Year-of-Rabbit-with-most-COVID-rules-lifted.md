# China rings in Year of Rabbit with most COVID rules lifted

- 来源：WHYY　|　发布：2023-01-22　|　作者：Associated Press　|　正文字符：5316
- 原文：https://whyy.org/articles/china-lunar-new-year-of-rabbit-most-covid-rules-lifted/

People across China rang in the Lunar New Year on Sunday with large family gatherings and crowds visiting temples after the government lifted its strict “zero-COVID” policy, marking the biggest festive celebration since the pandemic began three years ago. The Lunar New Year is the most important annual holiday in China. Each year is named after one of the 12 signs of the Chinese zodiac in a repeating cycle, with this year being the Year of the Rabbit. For the past three years, celebrations were muted in the shadow of the pandemic. With the easing of most COVID-19 restrictions that had confined millions to their homes, people could finally make their first trip back to their hometowns to reunite with their families without worrying about the hassles of quarantine, potential lockdowns and suspension of travel. Larger public celebrations also returned for what is known as the Spring Festival in China, with the capital hosting thousands of cultural events — on a larger scale than a year ago. “He has never experienced what a traditional new year is like because he was too young three years ago and he had no memory of that,” said Si Jia, who brought her 7-year-old son to the Qianmen area near Beijing’s Tiananmen Square to experience the festive vibe and learn about traditional Chinese culture. WHYY thanks our sponsors — become a WHYY sponsor Related Content Community LA mass shooting suspect kills 10 near Lunar New Year fest

Nearly 53,000 offered prayers at Beijing’s Lama Temple but the crowds appeared to be smaller compared to pre-pandemic days. The Tibetan Buddhist site allows up to 60,000 visitors a day, citing safety reasons, and requires an advance reservation. Throngs of residents and tourists swarmed pedestrian streets in Qianmen, enjoying snacks from barbecue and New Year rice cake stands, and some children wore traditional Chinese rabbit hats. Others held blown sugar or marshmallows shaped like rabbits. At Taoranting Park, there was no sign of the usual bustling new year food stalls despite its walkways being decorated with traditional Chinese lanterns. A popular temple fair at Badachu Park that was suspended for three years will be back this week, but similar events at Ditan Park and Longtan Lake Park have yet to return. The mass movement of people may cause the virus to spread in certain areas, said Wu Zunyou, the chief epidemiologist at China’s Center for Disease Control. But a large-scale COVID-19 surge will be unlikely in the next two or three months because about 80% of the country’s 1.4 billion people have been infected during the recent wave, he wrote on the social media platform Weibo on Saturday. WHYY thanks our sponsors — become a WHYY sponsor Related Content Things To DoArts & Entertainment Lunar New Year celebrations, Longwood’s Winter Wonder, Philly Tattoo Fest in this week’s ‘Things To Do’

The center reported 12,660 COVID-19-related deaths between Jan. 13 and 19, including 680 cases of respiratory failure caused by the virus and 11,980 fatalities from other ailments combined with COVID-19. These are on top of 60,000 fatalities reported last week since early December. The statement on Saturday said the deaths occurred in hospitals, which means anyone who died at home would not be included in the tally.

China has counted only deaths from pneumonia or respiratory failure in its official COVID-19 death toll, a narrow definition that excludes many deaths that would be attributed to COVID-19 in much of the world.

In Hong Kong, revelers flocked to the city’s largest Taoist temple, Wong Tai Sin, to burn the first incense sticks of the year. The popular ritual was suspended the last two years due to the pandemic.

Traditionally, big crowds gather before 11 p.m. on Lunar New Year’s Eve, with everyone trying to be the first, or among the first, to put their incense sticks into the stands in front of the temple’s main hall. Worshippers believe those who are among the first to place their incense sticks will stand the best chance of having their prayers answered.

Resident Freddie Ho, who visited the temple on Saturday night, was happy that he could join the event in person.

“I hope to place the first incense stick and pray that the New Year brings world peace, that Hong Kong’s economy will prosper, and that the pandemic will go away from us and we can all live a normal life,” Ho said. “I believe this is what everyone wishes.”

Meanwhile, the crowds praying for good fortune at the historic Longshan Temple in Taipei, the capital of Taiwan, were smaller than a year ago even as the pandemic has eased. That is partly because many had ventured to other parts of Taiwan or overseas on long-awaited trips.

As communities across Asia welcomed the Year of the Rabbit, the Vietnamese were celebrating the Year of the Cat instead. There’s no official answer to explain the difference. But one theory suggests cats are popular because they often help Vietnamese rice farmers to chase away rats.

___

Leung reported from Hong Kong. Associated Press journalists Henry Hou, Olivia Zhang in Beijing, Alice Fung in Hong Kong and Taijing Wu in Taipei, Taiwan contributed to this report.

WHYY is your source for fact-based, in-depth journalism and information. As a nonprofit organization, we rely on financial support from readers like you. Please give today.
