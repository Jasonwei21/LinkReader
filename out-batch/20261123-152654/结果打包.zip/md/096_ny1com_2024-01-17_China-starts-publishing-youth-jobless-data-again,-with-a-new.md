# China starts publishing youth jobless data again, with a new method and a lower number

- 来源：ny1.com　|　发布：2024-01-17　|　作者：Associated Press　|　正文字符：1694
- 原文：https://ny1.com/nyc/all-boroughs/ap-top-news/2024/01/17/china-starts-publishing-youth-jobless-data-again-with-a-new-method-and-a-lower-number

HONG KONG (AP) — China published youth unemployment data Wednesday for the first time since the jobless rate hit a record high in June last year, using a new method that showed an apparent improvement.

China announced a 14.9% jobless rate for people between 16 and 24 in December, using the new method, which excludes students. The statistics bureau stopped publishing the politically sensitive figure last year, after it reached 21.3% in June.

The change in methodology came after youth unemployment surged following an economic slowdown in 2023. Regulatory crackdowns on sectors like technology and education, which typically employed a younger workforce, also made jobs harder to find.

Previously, the youth unemployment rate counted students who worked at least one hour a week as employed, and those who said they wanted jobs but could not find them as unemployed. It's not clear how the methodological change affects the stated unemployment rate.

“Calculating the unemployment rate by age group that does not include school students will more accurately reflect the employment and unemployment situation of young people entering society,” the statistics bureau said in a statement, adding that students should focus on their studies instead of finding jobs.

Excluding school students from the jobless rate will allow authorities to provide youths with “more precise employment services, and formulate more effective and targeted employment policies,” the bureau said.

The bureau also published an unemployment rate for 25 to 29-year-olds for the first time, to reflect the employment situation of university graduates. That jobless rate, which also excludes students, stood at 6.1% in December.
