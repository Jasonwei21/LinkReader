# China says April exports jump 14.1% from a year ago ahead of Trump-Xi summit

- 来源：WKMG　|　发布：2026-05-09　|　作者：Associated Press　|　正文字符：3262
- 原文：https://www.clickorlando.com/business/2026/05/09/china-says-exports-grew-at-faster-pace-in-april-rising-141-from-a-year-ago/

Associated Press

HONG KONG – China’s exports rose 14.1% in April from a year earlier, the government said Saturday, despite the Iran war and lingering impacts from higher U.S. tariffs.

The data were released just days ahead of a planned meeting next week between U.S. President Donald Trump and Chinese leader Xi Jinping in Beijing.

Recommended Videos

That beat analysts’ estimates and was a significant improvement from March’s 2.5% year-on-year expansion. Exports to the U.S. rose 11.3% from the year before, up from a 26.5% drop in March.

Imports climbed 25.3%, slower than the 27.8% growth in March but still robust.

The Trump-Xi summit comes at a time when relations are beset by multiple issues, with efforts to end the war in Iran eclipsing the usual sources of friction.

“We’re expecting that overall external demand will remain a solid driver of growth this year,” said Lynn Song, chief economist for Greater China at Dutch bank ING, likely led by China’s exports of semiconductors and autos.

In March, Chinese leaders set an annual economic growth target of 4.5% to 5%, slightly lower than last year’s 5% expansion and the lowest target since 1991. Export growth is expected to continue to power its wider economy, especially as shipments increased from China to Europe, Southeast Asia, Latin America and Africa over the past months.

China’s exports to the U.S. have fallen for most of the months since Trump imposed steeper tariffs and harsher controls on sharing of technology after he took office last year. But trade with the U.S. is likely improving this year, said Song, particularly because of the base effects of sharp declines caused by Trump’s tariff hikes in 2025.

Apart from efforts to broker a peace agreement to end the Iran war, trade and export controls, including rare earths and U.S. tech restrictions on China, will likely be on the agenda during the Trump-Xi summit, following a yearlong U.S.-China trade truce reached late last year when the two leaders last met in South Korea.

Major breakthroughs on export controls are unlikely, but the leaders’ upcoming meeting may bring “incremental” steps to troubleshoot trade friction, HSBC economists said in a recent research note.

“On balance, China looks to have more leverage,” wrote Leah Fahy, senior China economist of Capital Economics, in a note. “But higher tariffs haven’t stopped China’s exports from continuing to surge over the past year, and Beijing has showed that it is prepared to wait out U.S. pressure.”

For China, oil and fuel price hikes caused by the war in Iran are also feeding higher manufacturing and logistics costs across its many factories, said Wei Li, head of multi-asset investments at BNP Paribas Securities (China), while higher global inflation could dampen consumer purchasing power in China’s overseas markets.

Still, China’s overall economy has remained resilient compared with other countries, owing to its large oil reserves and more diversified energy sources.

ING’s Song said China’s trade surplus, which reached an all-time high of almost $1.2 trillion last year, could narrow for the whole of this year. Imports so far have been stronger in 2026, though China is still recovering from a prolonged property slump that has dragged on consumption and investment.
