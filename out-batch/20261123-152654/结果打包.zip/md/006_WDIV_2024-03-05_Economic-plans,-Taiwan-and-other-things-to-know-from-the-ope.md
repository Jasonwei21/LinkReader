# Economic plans, Taiwan and other things to know from the opening of China's legislature

- 来源：WDIV　|　发布：2024-03-05　|　作者：Huizhong Wu　|　正文字符：4588
- 原文：https://www.clickondetroit.com/news/world/2024/03/05/what-you-should-know-from-the-opening-of-chinas-legislature/

#### World

## Economic plans, Taiwan and other things to know from the opening of China's legislature

Huizhong Wu

Associated Press

A delegates leaves the hall after Chinese Premier Li Qiang delivered his work report at the opening session of the National People's Congress (NPC) at the Great Hall of the People in Beijing, Tuesday, March 5, 2024. China's official growth target for this year is around 5%, Premier Li Qiang said Tuesday in an annual report on the government's plans and performance that prioritized both security and the economy. (AP Photo/Andy Wong)

BEIJING – China's Premier Li Qiang promoted an image of confidence as he announced modest economic growth goals for the world's second largest economy, at one of the country's most important political gatherings.

Li addressed a few thousand delegates of the country's rubber-stamp legislature, the National People's Congress, which met in Beijing.

Recommended Videos

It's a time when the government reviews the work of the past year, and crucially reveals targets and goals for the coming year, especially in its approach to its economy, military budget and Chinese society.

Here are some key takeaways from Li's address Tuesday.

STABLE ECONOMIC GROWTH

The government's overall approach to the economy will not change, as the goals by the government for 2024 signal that they want to stabilize growth. Li announced that the GDP growth target was 5% this year — a modest target that is still going to be difficult. China is grappling with an economic slowdown and a real estate market in crisis after a crackdown on excess borrowing led to a liquidity crisis among developers.

“This year’s targets are virtually the same as last year, reflecting policy stasis in Beijing as the central leadership delays any significant economic policy decisions until the Third Plenum later in the year,” said Neil Thomas, a fellow on Chinese Politics at the Asia Society.

TOUGHER LANGUAGE ON TAIWAN

Li's report had stronger language on Taiwan, a self-ruled island that China considers its own.

Missing from this year's report was the word “peace.” Last year, the premier had called for “advanc(ing) the process of China’s peaceful reunification.” This year, Li said they will “be firm in advancing the cause of China’s reunification.”

Overall, the language this year was tougher, said Arthur Zhin-Sheng Wang, a professor at Taiwan’s Central Police University who’s an expert on cross-Straits relations.

Dropping the word “peace” combined with the phrase “resolutely opposing Taiwan independence,” is what signals a stronger stance, Wang said. Last year, the work report had more language about promoting the prosperity of both sides as well, while this year only had a brief nod.

Taiwan held presidential elections in January and elected Lai Ching-te to be its next president, giving the Democratic Progressive Party a third term. The party's platform maintains that Taiwan is already independent of China.

Taiwan and China have been ruled separately since 1949, when the Nationalist government of Chiang Kai-shek retreated to the island after losing a civil war on the mainland to Mao Zedong’s communist forces.

DEFENSE SPENDING RISING 7.2%

The government announced an increase of 7.2% in the military budget, the world’s second-highest behind the United States at 1.6 trillion yuan ($222 billion). China’s defense budget has more than doubled since 2015, but in recent years it has dialed down the increase in defense spending as economic growth slowed.

MIGRANT WORKERS

China's rural and urban populations have long been divided by the hukou, a registration and identification system through which social benefits are allocated, such as health insurance and schools. Cities and urban areas generally have better social benefits than rural ones.

For the first time in recent years, the government's work report mentioned that it would want to make it easier for migrant workers with rural hukou registrations to be able to change their hukous to urban ones. While hukou reform has long been discussed, the mention in the government report signals that it could be higher on the agenda of the central authorities.

CONFIDENCE

In spite of the slowing economy, and U.S. export controls on several tech-related industries, such as semi-conductors, Li struck a note of confidence in his report.

“The Chinese people have the courage, wisdom, to overcome any difficulties or obstacles,” he said. “China's development will surely endure storms and plough through the waves, (and) the future is promising.”

___

AP news researchers Yu Bing and Wanqing Chen contributed to this report.
