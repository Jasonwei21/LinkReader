# Indonesian president launches Southeast Asia's first high-speed railway, funded by China

- 来源：ny1.com　|　发布：2023-10-02　|　作者：Associated Press　|　正文字符：3582
- 原文：https://ny1.com/nyc/all-boroughs/ap-top-news/2023/10/02/indonesian-president-launches-southeast-asias-first-high-speed-railway-funded-by-china

JAKARTA, Indonesia (AP) — Indonesian President Joko Widodo inaugurated Southeast Asia’s first high-speed railway on Monday as it was set to begin commercial operations, a key project under China’s Belt and Road infrastructure initiative that will drastically reduce the travel time between two key cities.

The project has been beset with delays and increasing costs, and some observers doubt its commercial benefits. But Widodo has championed the 142-kilometer (88-mile) railway, which was issued its official operating license from the Transportation Ministry on Sunday.

The $7.3 billion project, largely funded by China, was constructed by PT Kereta Cepat Indonesia-China, known as PT KCIC, a joint venture between an Indonesian consortium of four state-owned companies and China Railway International Co. Ltd.

Widodo in his opening remarks officially named Indonesia's first high-speed railway — the fastest in Southeast Asia, with speeds of up to 350 kph (217 mph) — as “Whoosh,” from “Waktu Hemat, Operasi Optimal, Sistem Handal,” which means “timesaving, optimal operation, reliable system” in Indonesian language.

“Our courage to try new things gives us confidence and the opportunity to learn and will be very useful for the future, making our human resources more advanced and our nation more independent,” he added.

Widodo, along with other high-ranking officials, rode Whoosh from its first station, Halim in eastern Jakarta, to Bandung’s Padalarang station, one of the line’s four stations, located about 30 kilometers (18 miles) from the central area of Bandung.

Luhut Binsar Pandjaitan, the coordinating minister for maritime and investment, said China Railway has agreed to transfer its technology to Indonesia so that in the future the country’s high-speed trains can be made domestically.

Indonesia broke ground on the project in 2016. The line was originally expected to begin operations in 2019, but was delayed by disputes over land acquisition, environmental issues and the COVID-19 pandemic. It was planned to cost 66.7 trillion rupiah ($4.3 billion), but the amount ballooned to 113 trillion rupiah ($7.3 billion).

The trains have been modified for Indonesia’s tropical climate and are equipped with a safety system that can respond to earthquakes, floods and other emergency conditions. The 209-meter (685-foot) train has a capacity of 601 passengers.

The rail deal was signed in October 2015 after Indonesia selected China over Japan in fierce bidding. It was financed with a loan from the China Development Bank for 75% of the cost. The remaining 25% came from the consortium’s own funds.

The project is part of a planned 750-kilometer (466-mile) high-speed train line that would cut across four provinces on Indonesia’s main island of Java and end in the country’s second-largest city, Surabaya.

As a global economic giant, China is one of the largest sources of foreign direct investment in Southeast Asia, a region home to more than 675 million people. Amid crackdowns by the United States and its allies, China is expanding trade with ASEAN countries and infrastructure projects are playing key roles.

A semi-high-speed railway — with speeds up to 160 kph (99 mph) — linking China with Laos was inaugurated in December 2021. The $6 billion infrastructure was financed mostly by China under the Belt and Road policy. The 1,035-kilometer (643-mile) route runs through Laos' mountain ranges to connect the southeastern Chinese city of Kunming with Vientiane, the capital of Laos. There are plans for a high-speed train down through Thailand and Malaysia to Singapore.
