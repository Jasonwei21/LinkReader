# Goldman Sees China Nearly Tripling Its Target for Wind and Solar

- 来源：Energy Connects　|　发布：2023-03-14　|　作者：Bloomberg　|　正文字符：3374
- 原文：https://www.energyconnects.com/news/renewables/2023/march/goldman-sees-china-nearly-tripling-its-target-for-wind-and-solar/

By Bloomberg

Mar 14, 2023

Photovoltaic panels at a solar farm operated by Yellow River Power in Gonghe County, Qinghai province, China, on Monday, Sept. 27, 2021. China, the world's biggest greenhouse gas emitter, can’t meet its environmental goals without connecting its abundant sources of renewable energy with its coastal megacities. Photographer: Qilai Shen/Bloomberg

(Bloomberg) -- China is likely to install nearly three times more wind turbines and solar panels by 2030 than it’s current target, helping drive the world’s biggest fuel importer toward energy self-sufficiency, according to Goldman Sachs Group Inc.

Falling costs will make around-the-clock clean power increasingly profitable, leading to the rapid deployment of renewables and batteries, analysts including Nikhil Bhandari and Amber Cai said in a report on Monday. Solar and wind capacity will reach 3,300 gigawatts by 2030, well ahead of the government’s target of 1,200 gigawatts.

Such a vast fleet of intermittent generation will require about 520 gigawatts of energy storage, around 410 gigawatts of which would come from batteries and the rest from pumped hydro facilities, according to the analysts. That means battery storage capacity would be 70 times higher than the level seen at the end of 2021.

China’s rapid energy transition will require about $8 trillion of investment through 2040 in power generation, storage and grid upgrades. Still, decoupling power from fossil fuels will lead to lower, and less volatile, generation costs from 2030, the analysts said.

It will also allow China — the world’s biggest oil, gas and coal importer — to reduce its dependence on foreign fuels. By 2060, China’s energy imports will fall to just 92 million tons of coal equivalent, from 1.14 billion tons in 2021, the analysts forecast.

Goldman’s forecasts aren’t dissimilar to other researchers. In a scenario designed to put China on the pathway to reaching net zero emissions by 2050 — 10 years ahead of Beijing’s current target — BloombergNEF estimated the country would have 3,345 gigawatts of wind and solar and 392 gigawatts of energy storage by 2030.

More stories like this are available on bloomberg.com

By Dan Murtaugh

## KEEPING THE ENERGY INDUSTRY CONNECTED

## Latest Articles

### EU Rejected UN Climate Deal Due to Backsliding on Fossil Fuels

### Senate Passes Landmark Bill to Overhaul US Energy Permitting

### Republican Lawmakers Urge EPA to Reinstate Solar for All Program

### Senate Permitting Bill Authors Seek Data Center Exemption

## Watch/Listen

As energy demand rises and AI-driven technologies reshape the industry, oil and gas operators are under increasing pressure to deliver secure, resilient and efficient operations.…

### Balancing energy security and transition in the Middle East

In an exclusive Energy Connects studio interview recorded at ADIPEC 2026, Ashish Gupta, Head of Sales & Vice President Business Development, Technip Energies, discusses the…

### The roadmap to low-carbon fuels and a net-zero future

In the latest episode of the Energy Connects podcast, Yassir Ghiyati, Chief Commercial Officer at Topsoe, explores the realities of scaling low-carbon fuels in today’s…

### AI, electrification, and the race to future-proof energy infrastructure

In an exclusive Energy Connects studio podcast recorded at ADIPEC 2026, Bruno Melles, Executive Vice President and CEO, Transformers Business Unit, Hitachi Energy, explores the…
