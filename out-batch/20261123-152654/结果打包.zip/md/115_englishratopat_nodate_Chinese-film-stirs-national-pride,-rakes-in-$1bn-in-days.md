# Chinese film stirs national pride, rakes in $1bn in days

- 来源：english.ratopati.com　|　正文字符：2026
- 原文：https://english.ratopati.com/story/39036

The film is based on a Chinese mythological character of the same name. (Getty Images)

Beijing, February 10 — An animated film about a boy who battles demons with his magical powers has become China's highest-grossing film ever and a source of national pride.

Ne Zha 2, based on a Chinese mythological character, has raked in more than 8 billion yuan ($1.1bn; £910m) during the week-long Lunar New Year holiday, according to ticket sales tracker Maoyan.

It broke the record set by 2021's The Battle of Lake Changjin, a propaganda film about the 1950s Korean War, which earned about $900m.

Ne Zha 2 is being hailed as a symbol of progress in Chinese film, which has long trailed Hollywood despite a massive domestic market.

Hot off its domestic success, Ne Zha 2 will be shown overseas next week, including in the US, Canada and Australia.

To Chinese viewers, Ne Zha 2 shows how locally-made films are becoming competitive globally.

"It not only showcases the strong power of Chinese animation after its rise, but also demonstrates the infinite possibilities of traditional Chinese mythology in the modern context," reads one review on IMDB.

Some hope it could earn another $1bn and surpass the world's highest-grossing film of all time, 2009's Avatar.

"Now it's over to the Chinese people overseas to chip in," read one comment on Weibo.

Movie ticket sales in China surge during the Lunar New Year festivities. This season saw Chinese films rake in $1.3b during the weeklong holiday period, underscoring an increase in consumer spending that Chinese authorities have been hoping for.

Aside from setting a new box-office benchmark in China, Ne Zha 2 is also the first movie ever to cross $1bn in a single market, according to Hollywood publication Deadline.

Ne Zha 2 has been praised for its script and visual effects. Figurines of the movie's characters have flown off the shelves as fans flock to cinemas.

It builds on the success of the 2019 film Ne Zha, which made more than $725m and is China's fifth highest-grossing film of all time.
