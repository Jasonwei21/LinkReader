# China economy slows as power cuts, property woes and Covid take toll

- 来源：the Guardian　|　发布：2021-10-18　|　作者：Martin Farrer　|　正文字符：5049
- 原文：https://www.theguardian.com/business/2021/oct/18/china-economy-slows-as-power-cuts-property-woes-and-covid-take-toll

GDP grew 4.9% in the quarter to September, the lowest for a year, as the post-pandemic recovery loses steam and Evergrande problems persist

China’s economy grew slower than expected in the third quarter, official data showed on Monday, thanks to power outages, supply bottlenecks, Covid outbreaks, and concerns about the struggling property sector.

Although China’s central bank governor said the country is “doing well”, independent economists predicted that the mounting array of headwinds suggest a “deeper downturn” resulting in the country’s weakest growth for more than a decade next year.

Gross domestic product (GDP) expanded 4.9% in the July-September quarter from a year earlier, the national statistics bureau said on Monday, slowing from 7.9% in April-June and compared with expectations for a rise of 5.2% expected by economists.

The result was the weakest reading since last year’s third quarter, when GDP also grew 4.9%, and marked a further deceleration from a record 18.3% expansion in the first quarter.

However, more worryingly for Beijing’s economic managers, on a quarterly basis, growth was just 0.2% between July-September from 1.2% in the second quarter, the data showed. This is the weakest ever recorded since quarterly figures were first published in 2010.

New construction starts in September fell 13.54% from a year earlier, the third month of double-digit declines, according to Reuters calculations.

Along with concerns that the property developer China Evergrande Group may officially default on its offshore debts this week, it will add to concerns that the property sector, which accounts for up to 25% of GDP, could drag the whole economy in to a slump.

Stocks were sold off across Asia in the wake of the news, with Hong Kong the worst hit with a loss of 0.53% on the Hang Seng. The price of crude oil rose by more than $1 to $85.89

Julian Evans-Pritchard, senior China economist at Capital Economics, said his consultancy’s “activity proxy” measure now pointed to a “sharp contraction” in GDP.

“Although some of the recent weakness in services is now reversing, industry and construction appear on the cusp of a deeper downturn.

“For now, the blow from the deepening property downturn is being softened by very strong exports. But over the coming year, foreign demand is likely to drop back as global consumption patterns normalise coming out of the pandemic and backlogs of orders are gradually cleared. All told, we expect growth of just 3% on our China activity proxy next year, the slowest pace since the global financial crisis.”

The world’s second-largest economy has staged an impressive rebound from the pandemic but the recovery is losing steam. Problems including faltering factory activity, power cuts in the country’s crucial northern industrial heartland, and a slowing property sector have fanned speculation that policymakers may announce more stimulus measures in coming months.

Chief among the concerns about the giant property sector is the future of China Evergrande Group, the country’s number two developer which is struggling under a $300bn mountain of debt.

It has already missed three repayments on bonds that it owes overseas investors in US dollars, and trade in its shares in Hong Kong has been suspended since 4 October.

The crisis could reach a head this week when the 30-day grace period is up on the first tranche of repayments – worth $83.5m – that were missed in September .

But the head of China’s central bank, Yi Gang, said on Sunday the economy was “doing well” although it faced challenges such as default risks for certain firms due to “mismanagement”.

Yi said default risks for some firms and operational difficulties among small and mid-sized banks were among the challenges for China’s economy, and that authorities were keeping a close eye “so they do not become systematic risks”.

Despite setbacks from coronavirus infections, China’s economy was expected to grow 8% this year, Yi said at an online meeting of the Group of 30 international banking seminar, which coincides with the annual meetings of the International Monetary Fund and World Bank.

“Economic growth has been slowed down a little bit, but the trajectory of economic recovery remains unchanged,” he said.

Authorities will first try to prevent problems at Evergrande spreading to other real estate companies to avoid a broader systematic risk, he added.

The rumbling crisis at Evergrande and other major homebuilders drove debt market risk premiums on weaker Chinese firms to a record high last week and triggered a fresh round of credit rating downgrades.

“The interest of creditors and shareholders will be fully respected strictly in accordance to law,” Yi said. “The law has clearly indicated the seniority of liabilities.” Authorities will give the highest priority to the protection of consumers and homebuyers, while respecting the rights of creditors and shareholders, he said.

China’s central bank was taking various steps to fend off financial risks, such as replenishing capital for small and midsize banks, Yi said.
