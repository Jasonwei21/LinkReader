# Chinese Premier Li Keqiang bows out as Xi loyalists take reins

- 来源：Los Angeles Times　|　发布：2023-03-06　|　正文字符：6525
- 原文：https://www.latimes.com/world-nation/story/2023-03-05/china-premier-li-keqiang-bows-out-as-xi-loyalists-take-reins

BEIJING — After a decade in the shadow of Chinese President Xi Jinping, Li Keqiang is taking his final bow as premier, marking a shift away from the skilled technocrats who have helped steer the world’s second-biggest economy in favor of officials known mainly for their unquestioned loyalty to the country’s most powerful leader in recent history.

After exiting the ruling Communist Party’s all-powerful Politburo Standing Committee in October — despite being below retirement age — Li on Monday undertook his last major task: delivering the state of the nation address to the rubber-stamp parliament. The report sought to reassure citizens of the resiliency of the Chinese economy but contained little that was new.

Once seen as a potential top leader, Li was increasingly sidelined as Xi accumulated power and elevated the military and security services in aid of the “great rejuvenation of the Chinese nation.” Li’s lack of visibility sometimes made it difficult for observers to remember that he was technically ranked No. 2 in the party.

For most of his career, Li was known as a cautious, capable and highly intelligent bureaucrat who rose through, and was bound by, a consensus-oriented Communist Party that reflexively stifles dissent.

As governor, then party secretary, of the densely populated agricultural province of Henan in the 1990s, Li squelched reporting on an AIDS outbreak tied to illegal blood-buying rings that pooled plasma and injected it into donors after removing the blood products, allegedly with the collusion of local officials.

While Li was not in office when the scandal broke, his administration worked to quiet it up, prevented victims from seeking redress and harassed private citizens working on behalf of orphans and others affected.

But Li also cut a modestly different profile: an English speaker from a generation of politicians schooled during a time of greater openness to liberal Western ideas. Introduced to politics during the 1966-76 Cultural Revolution, he made it into prestigious Peking University, where he studied law and economics, on his own merits rather than through connections.

After graduation, Li went to work at the Communist Youth League, an organization that grooms university students for party roles, at the time headed by future president and party leader Hu Jintao. Higher office soon followed.

Among the largely faceless ranks of Chinese bureaucrats, Li managed to show an unusually candid streak. In a U.S. State Department cable released by WikiLeaks, Li is quoted telling diplomats that Chinese economic growth statistics were ‘‘man-made’’ and saying he looked to electricity demand, rail cargo traffic and lending as more accurate indicators.

Yet he largely failed to make effective use of the platforms he was given, unlike his immediate predecessors. At his sole annual news conference on the closing day of each congressional annual session, Li used most of his time repeating talking points and reciting statistics. Throughout China’s three-year battle against COVID-19, Li was practically invisible.

Li had been seen as Hu’s preferred successor as president. But the need to balance party factions prompted the leadership to choose Xi, the son of a former vice premier and party elder, as the consensus candidate.

The two never formed anything like the partnership that characterized Hu’s relationship with his premier, Wen Jiabao — or Mao Zedong’s with the redoubtable Zhou Enlai — although Li and Xi never openly disagreed over fundamentals.

“Xi is not the first among equals but rather is way above equal,” said Cheng Li, an expert on the Chinese leadership at the Brookings Institute in Washington, D.C. Ultimately, Li was a “team player” who put party unity foremost, he said.

Meanwhile, Li’s authority was being gradually shrunk, beginning with a 2018 reorganization of offices. While some may have wished Li had been more influential or decisive, the ground was crumbling under his feet as Xi shifted more of the powers of the State Council, China’s Cabinet, to party institutions, Cheng Li said. That shift to expanded party control is expected to continue at the current congress meeting on an even greater scale.

His departure leaves questions about the future of the private sector that Xi has been reining in, along with wider economic reforms championed by Li and his cohort. His expected replacement, Li Qiang, a crony of Xi’s from his days in provincial government, is best known for his ruthless implementation last year of the monthslong COVID-19 lockdown in Shanghai.

“Li Keqiang has been associated with a more economics-focused take on governance, which contrasts strongly with the ideological tone that Xi has brought to politics,” said Rana Mitter of Oxford University. “Li may be the last premier of his type, at least for a while.”

Li may be remembered less for what he achieved than for the fact that he was the last of the technocrats to serve at the top of the Chinese Communist Party, said Carl Minzner, an expert on Chinese law and governance at New York’s Fordham University and the Council on Foreign Relations.

Li’s departure “marks the end of an era in which expertise and performance, rather than political loyalty to Xi himself, was the primary career criterion for ambitious officials seeking to rise up to higher office,” he said.

By continuing, you agree to our Terms of Service, which include arbitration and a class action waiver. You agree that we and our third-party vendors may collect and use your information, including through cookies, pixels and similar technologies, for the purposes set forth in our Privacy Policy such as personalizing your experience and ads.

- After the blue wave: A moderate Democrat and an anti-Trump Republican analyze results Host Beth Ruyak sits down with moderate Democrat David Townsend and anti-Trump Republican Rob Stutzman, who find themselves agreeing far more than expected.
- The Martyrdom of Lenny Bruce Lenny Bruce revolutionized the world of stand-up comedy in the 1960s, with unfiltered language and a fearless relish for taboo subjects like religion. But his pathbreaking act made him a target of the LA vice squad.
- Bonus: Russian recruitment and sabotage Over the last several years, as the war with Russia has intensified, Ukraine has increased its efforts to recruit soldiers from foreign countries, largely from those in Latin America, like Colombia. Thousands of Latino soldiers have enlisted and, if you listen to all four episodes of Call Sign Condor, you’ll meet several of them.
