# Beijing air quality plummets amid dust storm, pollution

- 来源：WKMG　|　发布：2023-03-10　|　作者：Associated Press　|　正文字符：2299
- 原文：https://www.clickorlando.com/tech/2023/03/10/beijing-air-quality-plummets-amid-dust-storm-pollution/

Associated Press

Haze and dust envelops buildings in Beijing, Friday, March 10, 2023. Skyscrapers disappeared into the haze and air quality plummeted as China's capital was enveloped in a dust storm and heavy pollution on Friday. (AP Photo/Mark Schiefelbein)

BEIJING – Skyscrapers in Beijing disappeared into the haze and air quality plummeted as China’s capital was enveloped in a dust storm and heavy pollution on Friday.

Concentrations of the tiny PM2.5 particles that can reach deep into the lungs and bloodstream entered a dangerous range on air quality monitoring sites, with the IQAir website showing an air quality index of 1,093, a “hazardous” level, many times higher than what are considered “unhealthy” levels.

Recommended Videos

Beijing was formerly notorious for its terrible air quality, but conditions had much improved in recent years as authorities took heavily polluting vehicles off the roads and moved coal-fired power plants and heavy industry to the surrounding provinces.

The capital also used to be known for regular springtime dust and sandstorms caused by winds blowing in from the loess hills along the upper sections of the Yellow River to the west. Anti-desertification efforts have helped reduce both the frequency and intensity of the storms that had often turned the surrounding air a cataclysmic yellowish-red.

Air quality also improved markedly after 2000, when much of China's industry was shuttered under lockdowns and quarantines mandated by China's strict “zero-COVID” policy.

In the face of a sluggish economy, China has been promoting coal-fired power, setting back efforts to cut climate-changing carbon emissions from the biggest global source.

China is one of the biggest investors in wind and solar, but jittery leaders called for more coal-fired power after economic growth plunged in 2021 and shortages caused blackouts and factory shutdowns. Russia’s attack on Ukraine added to anxiety that foreign oil and coal supplies might be disrupted.

China is the top producer and consumer of coal and the biggest source of air pollution and climate changing gasses.

The ruling Communist Party has rejected binding emissions commitments, citing its economic development needs, and Beijing has avoided joining governments that promised to phase out use of coal-fired power.
