# China’s old-age dependency ratio overtakes children for first time

- 来源：Internazionale　|　发布：2026-10-28　|　作者：Redazione　|　正文字符：2914
- 原文：https://www.internazionale.it/ultime-notizie-reuters/2026/10/28/china-s-old-age-dependency-ratio-overtakes-children-for-first-time

## Per la prima volta, in Cina l’indice di dipendenza degli anziani supera quello dei bambini

HONG KONG, Oct 28 - China is now supporting more people aged 65 and above than children, underscoring the impact of its rapidly ageing population and a declining birth rate.

• Data from China’s National Bureau of Statistics showed the old-age dependency ratio — the non-working-age population compared to the working-age population — was 23.1% in 2025, compared with 22% for children, Chinese state-affiliated media Yicai reported

• The ratio has risen steadily over the years, up from 15% in 2016 to more than 20% in 2021

• There are now more than 223 million people in China aged 65 and above compared with around 213 million children aged 14 and under, the data showed

• China’s population fell for a fourth straight year in 2025, as its birth rate dropped to a record low

• The country’s birth rate has been falling for decades, a result of the one-child policy in place from 1980 to 2015, as well as rapid urbanisation

• Authorities have rolled out a range of measures to encourage marriage and childbearing, including family subsidies, childcare support, and reduced childbirth-related medical costs

• They have also pledged to make urban life more supportive for young people, children and families

(Reporting by Farah Master in Hong Kong and the Beijing newsroom; Editing by Kate Mayberry)

HONG KONG, 28 ottobre - La Cina sostiene oggi un numero maggiore di persone di età pari o superiore a 65 anni rispetto ai bambini, a riprova dell’impatto del rapido invecchiamento della popolazione e del calo del tasso di natalità.

• I dati dell’Ufficio Nazionale di Statistica cinese hanno mostrato che l’indice di dipendenza degli anziani — ovvero il rapporto tra la popolazione non in età lavorativa e quella in età lavorativa — era pari al 23,1% nel 2025, rispetto al 22% dei bambini, secondo quanto riportato dal media cinese affiliato allo Stato Yicai

• L’indice è aumentato costantemente nel corso degli anni, passando dal 15% del 2016 a oltre il 20% nel 2021

• I dati indicano che attualmente in Cina ci sono oltre 223 milioni di persone di età pari o superiore a 65 anni, a fronte di circa 213 milioni di bambini di età pari o inferiore a 14 anni

• Nel 2025 la popolazione cinese è diminuita per il quarto anno consecutivo, mentre il tasso di natalità è sceso al minimo storico

• Il tasso di natalità del paese è in calo da decenni, a causa della politica del figlio unico in vigore dal 1980 al 2015, nonché della rapida urbanizzazione

• Le autorità hanno varato una serie di misure per incoraggiare il matrimonio e la natalità, tra cui sussidi familiari, sostegno all’assistenza all’infanzia e riduzione dei costi sanitari legati al parto

• Si sono inoltre impegnate a rendere la vita urbana più favorevole per i giovani, i bambini e le famiglie

(Reporter Farah Master da Hong Kong e dalla redazione di Pechino; editor Kate Mayberry)
