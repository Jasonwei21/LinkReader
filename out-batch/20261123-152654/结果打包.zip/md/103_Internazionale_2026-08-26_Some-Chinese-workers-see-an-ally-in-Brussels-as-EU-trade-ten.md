# Some Chinese workers see an ally in Brussels as EU trade tensions mount

- 来源：Internazionale　|　发布：2026-08-26　|　作者：Redazione　|　正文字符：10300
- 原文：https://www.internazionale.it/ultime-notizie-reuters/2026/08/26/some-chinese-workers-see-an-ally-in-brussels-as-eu-trade-tensions-mount

## Con l’acuirsi delle tensioni commerciali con l’Unione europea, alcuni lavoratori cinesi vedono in Bruxelles un alleato

By Claire Fu

SINGAPORE, Aug 26 (Reuters) - The European Union is finding support on an opponent’s turf ahead of trade talks with Beijing, as Chinese workers vent on social media about excessive overtime that critics say gives exporters an unfair advantage.

Europe, which last year ran a trade deficit with China of roughly $1 billion a day, has given Beijing until October to address growing imbalances that it says are hollowing out domestic industries and causing mass layoffs.

A key EU complaint is China’s weak domestic demand, caused in part by sluggish wages and insufficient labour protection, which is depressing imports - including from Europe - and is forcing Chinese producers to seek overseas markets.

Amid those tensions, one of Brussels’ older tools to tackle the issue is drawing greater attention on China’s heavily censored internet. The EU Forced Labour Regulation, adopted in 2024 and taking effect in December 2027, bans goods produced with imposed or involuntary work, including excessive overtime.

The regulation strikes a chord with many Chinese workers, who have long complained about the “996 culture” of 12-hour shifts, six days per week.

“I think the EU is right to sanction forced labour. Who agrees and who disagrees?” read a recent post on RedNote, China’s Instagram-like platform, drawing almost 3,000 likes before being removed.

Users in the comments section expressed support for sanctions and shared information on filing complaints with EU authorities.

Analysts say the online interest in the topic reflects growing concerns over a weakening labour market and mounting pressure from employers grappling with deflationary price wars fuelled by overcapacity and competition in export markets.

“Some workers have found that while a company may not be particularly concerned about an individual domestic overtime dispute, it may be far more concerned about losing access to Western markets,” said Mingwei Liu, director at the Centre for Global Work and Employment at Rutgers University.

China’s human resources ministry and the cyberspace administration, which oversees online content, did not respond to requests for comment.

INTERESTS OF CHINESE EXPORTERS AND WORKERS DIVERGE

On Douyin, China’s version of TikTok, videos tagged “EU reporting website” and “EU reporting procedures” received more than 200,000 views. One video explaining the formal complaints process received 5,442 likes and 714 shares.

Xiao Qiang, founder of the U.S.-based China Digital Times, which tracks Chinese censorship, said other platforms appear to be limiting the audience reach of such posts.

Nevertheless, Xiao said the topic’s emergence in spite of that shows many Chinese people do not view exporters’ interests as synonymous with national interest.

“History won’t remember its view count, but this was the first time someone connected domestic labour grievances directly to foreign law enforcement mechanisms,” he said.

An EU Commission source said its departments have received informal allegations of labour violations, including excessive overtime, but had not seen a noticeable increase in complaints recently.

Some social media users also suggested complaining to Washington.

In July, the U.S. imposed tariffs of up to 12.5% on goods from 60 trading partners, including the EU and China, citing failures to screen or curb forced labour.

A U.S. Customs and Border Protection spokesperson declined to discuss any complaints, citing confidentiality, but said evidence of “extreme, systemic unpaid overtime” could trigger supply-chain investigations.

CHINA STRUGGLES TO ENFORCE WORKER PROTECTIONS

Chinese people work more than 48 hours a week on average, versus the legal cap of 44, official figures show, suggesting poor worker rights enforcement.

Last year, some Chinese companies, including appliance maker Midea, announced mandatory clock-off times.

In an article in March, Lu Ming, a member of the Chinese People’s Political Consultative Conference (CPPCC), the country’s top political advisory body, called for stronger labour protections, warning of a backlash from trade partners.

“Other countries may view the price competitiveness of Chinese products as being derived from excessively intensive work and a poor quality of life,” Lu was cited by the CPPCC website as saying.

“This not only affects China’s image, but could also lead to substantive trade barriers.”

(Reporting by Claire Fu; Editing by Marius Zaharia and Thomas Derpinghaus)

Di Claire Fu

SINGAPORE, 26 agosto (Reuters) - L’Unione europea sta trovando sostegno proprio nel territorio dell’avversario in vista dei negoziati commerciali con Pechino, mentre i lavoratori cinesi si sfogano sui social media riguardo agli straordinari eccessivi che, secondo i critici, conferiscono agli esportatori un vantaggio sleale.

L’Europa, che lo scorso anno ha registrato un deficit commerciale con la Cina pari a circa 1 miliardo di dollari al giorno, ha dato a Pechino tempo fino a ottobre per affrontare i crescenti squilibri che, secondo l’Unione, stanno svuotando le industrie nazionali e causando licenziamenti di massa.

Una delle principali lamentele dell’Unione europea riguarda la debole domanda interna cinese, causata in parte dalla stagnazione dei salari e dall’insufficiente tutela dei lavoratori, che sta frenando le importazioni – comprese quelle dall’Europa – e sta costringendo i produttori cinesi a cercare mercati all’estero.

In questo contesto di tensioni, uno degli strumenti più datati di Bruxelles per affrontare la questione sta attirando maggiore attenzione sull’Internet cinese, soggetto a una forte censura. Il regolamento dell’Unione europea sul lavoro forzato, adottato nel 2024 ed entrato in vigore nel dicembre 2027, vieta i beni prodotti con lavoro imposto o involontario, compresi gli straordinari eccessivi.

Il regolamento trova riscontro in molti lavoratori cinesi, che da tempo lamentano la “cultura 996”, caratterizzata da turni di 12 ore, sei giorni alla settimana.

«Penso che l’Unione europea abbia ragione a sanzionare il lavoro forzato. Chi è d’accordo e chi non lo è?», recitava un recente post su RedNote, la piattaforma cinese simile a Instagram, che ha raccolto quasi 3.000 “mi piace” prima di essere rimosso.

Nella sezione dei commenti, gli utenti hanno espresso sostegno alle sanzioni e condiviso informazioni su come presentare reclami alle autorità dell’Unione europea.

Gli analisti sostengono che l’interesse online per l’argomento rifletta le crescenti preoccupazioni relative all’indebolimento del mercato del lavoro e alla pressione sempre maggiore esercitata dai datori di lavoro alle prese con guerre dei prezzi deflazionistiche alimentate dall’eccesso di capacità produttiva e dalla concorrenza nei mercati di esportazione.

«Alcuni lavoratori hanno constatato che, mentre un’azienda potrebbe non essere particolarmente preoccupata per una singola controversia interna sugli straordinari, potrebbe invece essere molto più preoccupata di perdere l’accesso ai mercati occidentali», ha affermato Mingwei Liu, direttore del Centre for Global Work and Employment presso la Rutgers University.

Il ministero delle risorse umane cinese e l’amministrazione del cyberspazio, che supervisiona i contenuti online, non hanno risposto alle richieste di commento.

GLI INTERESSI DEGLI ESPORTATORI E DEI LAVORATORI CINESI DIVERGONO

Su Douyin, la versione cinese di TikTok, i video contrassegnati con i tag «sito web di segnalazione dell’Unione europea» e «procedure di segnalazione dell’Unione europea» hanno ricevuto oltre 200.000 visualizzazioni. Un video che spiegava la procedura formale di reclamo ha ricevuto 5.442 “mi piace” e 714 condivisioni.

Xiao Qiang, fondatore del China Digital Times con sede negli Stati Uniti, che monitora la censura cinese, ha affermato che altre piattaforme sembrano limitare la portata di tali post.

Ciononostante, Xiao ha osservato che l’emergere dell’argomento, nonostante ciò, dimostra che molti cinesi non considerano gli interessi degli esportatori come sinonimo di interesse nazionale.

«La storia non ricorderà il numero di visualizzazioni, ma questa è stata la prima volta che qualcuno ha collegato direttamente le rivendicazioni sindacali interne ai meccanismi di applicazione della legge all’estero», ha affermato.

Una fonte dell’Unione europea ha dichiarato che i suoi dipartimenti hanno ricevuto segnalazioni informali di violazioni in materia di lavoro, tra cui straordinari eccessivi, ma non hanno riscontrato un aumento significativo dei reclami negli ultimi tempi.

Alcuni utenti dei social media hanno anche suggerito di presentare reclami a Washington.

A luglio, gli Stati Uniti hanno imposto dazi fino al 12,5% sulle merci provenienti da 60 partner commerciali, tra cui l’Unione europea e la Cina, adducendo come motivazione la mancata individuazione o repressione del lavoro forzato.

Un portavoce dell’Agenzia doganale e di protezione delle frontiere degli Stati Uniti ha rifiutato di commentare eventuali reclami, invocando la riservatezza, ma ha affermato che prove di «straordinari non retribuiti estremi e sistematici» potrebbero innescare indagini sulla catena di approvvigionamento.

LA CINA FATICA A FAR RISPETTARE LE TUTELE DEI LAVORATORI

I cinesi lavorano in media più di 48 ore alla settimana, contro il limite legale di 44, secondo i dati ufficiali, il che suggerisce una scarsa applicazione dei diritti dei lavoratori.

Lo scorso anno, alcune aziende cinesi, tra cui il produttore di elettrodomestici Midea, hanno annunciato orari di fine turno obbligatori.

In un articolo pubblicato a marzo, Lu Ming, membro della Conferenza consultiva politica del popolo cinese (CPPCC), il massimo organo consultivo politico del paese, ha chiesto una maggiore tutela dei lavoratori, mettendo in guardia da una reazione negativa da parte dei partner commerciali.

«Altri paesi potrebbero ritenere che la competitività dei prezzi dei prodotti cinesi derivi da un lavoro eccessivamente intensivo e da una scarsa qualità della vita», ha affermato Lu, secondo quanto riportato dal sito web della CPPCC.

«Ciò non solo incide sull’immagine della Cina, ma potrebbe anche portare a barriere commerciali sostanziali».

(Reporter Claire Fu; editor Marius Zaharia e Thomas Derpinghaus)
