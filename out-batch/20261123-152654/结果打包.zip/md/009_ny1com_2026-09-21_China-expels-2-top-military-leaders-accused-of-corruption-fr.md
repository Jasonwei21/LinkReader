# China expels 2 top military leaders accused of corruption from the ruling Communist Party

- 来源：ny1.com　|　发布：2026-09-21　|　作者：Associated Press　|　正文字符：1055
- 原文：https://ny1.com/nyc/all-boroughs/ap-top-news/2026/09/21/china-expels-2-top-military-leaders-accused-of-corruption-from-the-ruling-communist-party

BEIJING (AP) — China has purged the country's highest-ranking army general and another top military official from the ruling Communist Party over alleged corruption and disloyalty uncovered during a months-long investigation, state media said Monday.

The expulsions of Gen. Zhang Youxia, vice chair of the powerful Central Military Commission and second only to President Xi Jinping in the military hierarchy, and Gen. Liu Zhenli, the chief of staff of the commission’s Joint Staff Department, are seen as part of a long-running purge of military officials and a crackdown on corruption.

The two men were accused of being “disloyal and dishonest to the Party,” as well as abusing their power to help others with promotions while improperly accepting gifts and an “enormous amount of money,” the official Xinhua News Agency said.

Both men “seriously violated political discipline and political rules,” and also failed to “supervise their relatives and close staff members,” Xinhua said. Their cases were referred to military prosecutors, the news agency said.
