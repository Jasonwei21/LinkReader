# Nvidia's AI chip sales in China stall, as local chipmakers like Huawei take the lead

- 来源：Los Angeles Times　|　发布：2026-06-29　|　作者：Chan Ho-Him　|　正文字符：4894
- 原文：https://www.latimes.com/business/story/2026-06-29/nvidias-ai-chip-sales-in-china-stall-as-local-chipmakers-like-huawei-take-lead

- Click here to listen to this article
In the race between the U.S. and China to develop artificial intelligence, the battle over hardware and computing power is heating up as Chinese companies like Huawei overtake global industry leaders like Nvidia in their home market.

Jensen Huang, the CEO of computer chip giant Nvidia, was mobbed by onlookers as he hit the streets for the “zhajiangmian” noodles while visiting Beijing during U.S. President Donald Trump’s May summit with Chinese leader Xi Jinping. But his celebrity status has not translated into success in selling Nvidia’s advanced chips in China.

Controls imposed by Washington on exports of advanced technology due to national security concerns initially stalled sales of Nvidia’s advanced H200 AI chips there. By the time Huang won a reprieve, with Trump agreeing to their sale, Beijing had switched to encouraging use of domestically designed chips made by local rivals led by Huawei.

“Well, we were in China for 30 years, and before the export control banned Nvidia out of China we had about 95% market share, and so we were competing just fine,” he said in a recent interview with The Associated Press.

“We have to have, number one, make sure that we have national security and that we protect our nation, but we also simultaneously should go and compete and grow our technology industry and maximize our exports,” he said.

Since the U.S. in 2019 excluded Huawei, and later China in general, from buying some of the world’s most powerful computer chips and chipmaking machinery, Chinese semiconductor makers have rushed to become self-sufficient, developing their own chips and knowhow.

Santa Clara, California-based Nvidia and its main rival AMD, or Advanced Micro Devices, dominate in the U.S. AI chip sector and much of the global market, but Huawei has made big inroads in China as Chinese AI companies like DeepSeek drive a push for improved chip performance and cost-effectiveness.

A report by Bernstein, a global equity research and brokerage firm, estimated that Nvidia had about a 40% market share in China’s AI chips market in 2025, roughly matched by Huawei. Bernstein has predicted Nvidia’s market share will shrink to around 8% this year, while Huawei’s will likely grow to about 50%.

By some measures, Huawei’s most advanced commercial AI chips, the Ascend 950 series, can be seen as roughly comparable to Nvidia’s H200, considered in the industry to be among Nvidia’s most powerful products, according to industry analysts.

Last September, Huawei also said it was rolling out some of the world’s most powerful AI computing clusters, combining the power of thousands of chips like its global rivals, despite having to rely on Chinese-made semiconductors due to the U.S. export controls.

Asked at a recent event about how Huawei’s chip technology compares its rivals’, including in the United States, He Tingbo, head of Huawei’s semiconductor business, said: “We have found pretty good solutions.”

Nvidia designs the world’s most powerful AI chips. To make them, it relies on Dutch company ASML’s extreme ultraviolet lithography, or EUV, machines, which rely on U.S, components and technologies. Taiwan chipmaking giant TSMC uses those machines to make a large share of Nvidia’s top AI chips at its fabrication plants.

Huawei’s high-performance chips lag behind Nvidia’s most advanced technologies in many areas. Cutting edge technologies in China such as training AI models like DeepSeek’s still rely on Nvidia AI chips, analysts say.

Nvidia’s global sales are still expanding as AI demand surges. The company expects around $91 billion of revenue in May-July, up from nearly $82 billion in the previous quarter, excluding any data center compute revenue from China.

Paul Triolo, a partner at DGA-Albright Stonebridge Group, said it is likely there is “significant effort going into collaboration between DeepSeek and Huawei” to train future DeepSeek models on domestic hardware.

Nvidia engineered its H20 chips, stripping down their computing power, so they could be sold to China without violating U.S. restrictions. Up to last year, it was still selling H20 chips in China, although shipments were gradually declining, said Brady Wang, a Taipei-based semiconductor analyst with Counterpoint Research.

Beijing’s public stance on imports of H200 chips has been unclear and Nvidia has said it has not sold H200 chips in China. At Nvidia’s recent shareholders meeting, Huang said it had “yet to generate any revenue, and we are uncertain whether any imports will be allowed into the country.”

By continuing, you agree to our Terms of Service, which include arbitration and a class action waiver. You agree that we and our third-party vendors may collect and use your information, including through cookies, pixels and similar technologies, for the purposes set forth in our Privacy Policy such as personalizing your experience and ads.
