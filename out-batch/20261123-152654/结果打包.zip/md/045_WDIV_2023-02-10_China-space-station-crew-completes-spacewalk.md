# China space station crew completes spacewalk

- 来源：WDIV　|　发布：2023-02-10　|　作者：Associated Press　|　正文字符：2427
- 原文：https://www.clickondetroit.com/news/world/2023/02/10/china-space-station-crew-completes-spacewalk/

#### World

## China space station crew completes spacewalk

Associated Press

BEIJING – The crew of China’s orbiting space station has completed the first of several planned spacewalks of their six-month mission, pushing such activities into the realm of routine for the country’s astronauts.

The China Manned Space Agency said that, during Friday’s seven-hour extra-vehicular activity, Fei Junlong and Zhang Lu carried out a number of tasks, including installing extension pumps outside the Mengtian laboratory module. The third member of the Shenzhou-15 mission, Deng Qingming, assisted from inside the station. The three are scheduled to carry out several other spacewalks during their time on board.

Recommended Videos

China completed the Tiangong station in November with the addition of the third of three modules, centered on the Tianhe living and command module.

China built its own station after it was excluded from the International Space Station, largely due to U.S. objections over the Chinese space programs’ intimate ties to the People’s Liberation Army, the military wing of the ruling Communist Party.

International security concerns around China were underscored last week when the U.S. military shot down an alleged Chinese military spy balloon that had drifted across the continental United States. China has maintained it was a civilian weather balloon that blew off course.

Tiangong weighs about 66 tons — a fraction of the 465-ton International Space Station. It can accommodate up to six astronauts, though only three will be on board for each mission.

With a lifespan of 10 to 15 years, Tiangong could one day be the only space station still up and running if the ISS retires around the end of the decade as expected.

China in 2003 became the third government to send an astronaut into orbit on its own after the former Soviet Union and the United States. It conducted its first spacewalk in September 2008 and the tempo of such activities has increased since the launch of the Tianhe module in 2021.

The country has also chalked up uncrewed mission successes: Its Yutu-2 rover was the first to explore the little-known far side of the moon. Its Chang’e 5 probe also returned lunar rocks to Earth in December 2020 for the first time since the 1970s, and another Chinese rover is searching for evidence of life on Mars.

An eventual crewed mission to the moon is also under consideration, although no timeline has been offered.
